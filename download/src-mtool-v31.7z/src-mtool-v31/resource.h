/*
Source file for MouseTool
MouseTool clicks the mouse when the user pauses it,
helping reduce strain caused by using the mouse.
Copyright (C) 2000 by Jeff Roush
www.mousetool.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
Or www.gnu.org/home.html
*/

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MouseTool.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MOUSETOOL_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_OPTIONSDIALOG               129
#define IDB_STOPBITMAP                  130
#define IDB_GOBITMAP                    131
#define IDD_DIALOG1                     132
#define IDD_ABTDIALOG                   133
#define IDB_MEPICTURE                   134
#define IDD_EXPIRED_DIALOG              137
#define IDD_MOUSEDOWN                   138
#define IDD_SPLASH                      139
#define IDB_HEADER                      140
#define IDB_REGISTERED                  141
#define IDB_TRIALVERSION                142
#define IDD_STOPPEDDIALOG               143
#define IDD_EXPIRINGDLG                 144
#define IDB_TRIAL27                     145
#define IDB_RDN                         147
#define IDB_LDN                         149
#define IDB_DDN                         150
#define IDB_DFL                         152
#define IDB_LFL                         153
#define IDB_RFL                         154
#define IDB_DRAG                        157
#define IDB_FLAT                        158
#define IDB_MAKEBIG                     159
#define IDB_MAKESMALL                   160
#define IDB_DUP                         161
#define IDB_LUP                         162
#define IDB_RUP                         163
#define IDB_RDRAG                       164
#define IDB_RDFL                        165
#define IDB_RDDN                        166
#define IDB_RDUP                        167
#define IDD_ABTTRIALDLG                 168
#define IDD_EXPDDIALOG                  169
#define IDI_ICON1                       171
#define IDD_REGISTER_DIALOG             174
#define IDD_TEMPSTRDLG                  176
#define IDB_SPLASH                      177
#define IDD_OPT_GENERAL                 179
#define IDD_OPT_TIMING                  180
#define IDD_OPT_JOYSTICK                181
#define IDD_OPT_KEYS                    182
#define IDD_DLG_CONTEXT                 183
#define IDD_DLG_TYPE_DESCRIPTION        184
#define IDD_DLG_GET_HOTKEY              185
#define IDD_DLG_REGISTER                186
#define IDD_DLG_WELCOME                 187
#define IDR_MENU1                       188
#define IDI_ICON_RED                    189
#define IDD_DLG_OLD_COMCTL32            190
#define IDI_ICON_REVERSED               190
#define IDI_ICON_STOPPED                192
#define IDI_ICON_DOUBLE                 193
#define IDD_DLG_ALERT_SD                194
#define IDD_DLG_ALERT_NEXTCLICK         195
#define IDD_DLG_ALERT_CONTEXTS          196
#define IDD_DLG_EXTEND                  197
#define IDD_DLG_WARN_LEFT_HOTKEY        198
#define IDB_LRG_DDN                     199
#define IDB_LRG_DFL                     200
#define IDB_LRG_DRAG                    201
#define IDB_LRG_LDN                     202
#define IDB_LRG_DUP                     203
#define IDB_LRG_FLAT                    204
#define IDB_LRG_LFL                     205
#define IDB_LRG_LUP                     206
#define IDB_LRG_RDDN                    207
#define IDB_LRG_RDFL                    208
#define IDB_LRG_RDN                     209
#define IDB_LRG_RDRAG                   210
#define IDB_LRG_RDUP                    211
#define IDB_LRG_RFL                     212
#define IDB_LRG_RUP                     213
#define IDD_DLG_ALERT_CK_CLICK          214
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_HELPBUTTON                  1001
#define IDC_REGISTERBUTTON              1001
#define IDC_BUTTON_RIGHT_KEY            1001
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_HOOKTEST                    1003
#define IDC_EDT_RIGHT_KEY               1003
#define IDC_EDT_CODE                    1003
#define IDC_EDIT3                       1004
#define IDC_OPTIONSBUTTON               1005
#define IDC_TICKS                       1007
#define IDC_STATUSTEXT                  1008
#define IDC_CHECK1                      1009
#define IDC_CONFIGCHECK                 1010
#define IDC_JOYPROGRESS                 1012
#define IDC_DRAG_CHECK                  1013
#define IDC_TIMER_CHECK                 1014
#define IDC_MINSTOWAIT                  1015
#define IDC_TIME_TO_GO                  1016
#define IDC_REVERSE_CHECK               1017
#define IDC_SLOW_CLICK_CHECK            1018
#define IDC_SLOW_CLICK_DELAY_EDIT       1019
#define IDC_SLOW_CLICK_STATIC           1020
#define IDC_STRETCH_BREAK_STATIC        1021
#define IDC_NEXT_BREAK_STATIC           1022
#define IDC_STATIC1                     1023
#define IDC_TICK_CHECK                  1024
#define IDC_TRIAL                       1026
#define IDC_STARTUPCHECK                1027
#define IDC_DOUBLEBUTTON                1028
#define IDC_LEFTBUTTON                  1029
#define IDC_RIGHTBUTTON                 1030
#define IDC_LSTATIC                     1031
#define IDC_DSTATIC                     1032
#define IDC_RSTATIC                     1033
#define IDC_SMALLBUTTON                 1034
#define IDC_SHOW_DRAG_CHECK             1035
#define IDC_MONITORJOYCHECK             1036
#define IDC_JOYSTATIC                   1037
#define IDC_ORDERINFOEDIT               1038
#define IDC_MESTATIC                    1039
#define IDC_REGBUTTON                   1040
#define IDC_SHARELOCK                   1041
#define IDC_FULL_CODE_BUTTON            1043
#define IDC_EDTTEMP_STR                 1044
#define IDC_TEST_BUTTON                 1046
#define IDC_EDIT_KEY                    1047
#define IDC_KEEP_ON_TOP                 1048
#define IDC_AUDIBLE_TICK                1049
#define IDC_EDT_DWELL_ZONE              1050
#define IDC_CK_ENABLE_CONTEXT           1051
#define IDC_LIST1                       1053
#define IDC_LST_APPS                    1053
#define IDC_RADIO_DEFAULT               1062
#define IDC_RADIO1                      1064
#define IDC_RADIO2                      1065
#define IDC_RADIO3                      1066
#define IDC_RADIO4                      1067
#define IDC_EDT_LAST_CONTEXT            1068
#define IDC_BUTTON_ADD_CONTEXT          1069
#define IDC_RADIO5                      1070
#define IDC_EDT_TYPE_DESCRIPTION        1071
#define IDC_BUTTON_DELETE_CONTEXT       1072
#define IDC_STATIC_PREV_WINDOW          1073
#define IDC_STAT_LAST_CONTEXT           1073
#define IDC_SMART_DRAG_CHECK            1074
#define IDC_SMART_DRAG_DELAY_EDIT       1075
#define IDC_SMART_DRAG_STATIC           1076
#define IDC_STAT_SMART_DRAG             1076
#define IDC_SMART_DRAG_FRAME            1077
#define IDC_STRETCH_TIMER_CHECK         1078
#define IDC_STATIC_STRETCH_FRAME        1079
#define IDC_BUTTON_ABOUT                1080
#define IDC_CK_OVERRIDE_NEXT_CLICK      1081
#define IDC_BUTTON_DBL_KEY              1082
#define IDC_EDT_DBL_KEY                 1083
#define IDC_EDT_HOTKEY                  1084
#define IDC_EDT_LEFT_BUTTON             1084
#define IDC_EDT_RIGHT_BUTTON            1085
#define IDC_STAT_HOTKEY                 1086
#define IDC_STAT_HOTKEY_FRAME           1086
#define IDC_CK_ENABLE_HOTKEYS           1087
#define IDC_STAT_DBL_KEY                1088
#define IDC_STAT_RIGHT_KEY              1089
#define IDC_EDT_DBL_BUTTON              1090
#define IDC_EDT_TOGGLE_BTN              1091
#define IDC_EDT_STOP_KEY                1092
#define IDC_STAT_STOP_KEY               1093
#define IDC_BUTTON_STOP_KEY             1094
#define IDC_STAT_ACTION                 1095
#define IDC_STAT_WND_TYPES              1096
#define IDC_STAT_LST_APPS               1096
#define IDC_BTN_DEL                     1097
#define IDC_EDT_NAME                    1098
#define IDC_STAT_DWELL_TIME             1099
#define IDC_STAT_DWELL_ZONE             1100
#define IDC_STAT_MINS_BTWN_BREAK        1101
#define IDC_STAT_MINS_TO_NEXT_BREAK     1102
#define IDC_STATIC_VERSION              1103
#define IDC_BUTTON_RIGHT                1104
#define IDC_BUTTON_DOUBLE               1105
#define IDC_BUTTON_LEFT                 1106
#define IDC_STAT_LEFT_BUTTON            1107
#define IDC_STAT_RIGHT_BUTTON           1108
#define IDC_STAT_DOUBLE_BUTTON          1109
#define IDC_STAT_FRAME_BUTTONS          1110
#define IDC_STAT_TOGGLE_LEFT            1111
#define IDC_BUTTON_TOGGLE               1112
#define IDC_STAT_COMUPD                 1114
#define IDC_BUTTON_GET_FILES            1115
#define IDC_CK_DONT_REMIND              1116
#define IDC_STAT_TRIAL                  1117
#define IDC_CK_DONT_SHOW_AGAIN          1118
#define IDC_CK_MOUSE_DN                 1119
#define IDC_CK_DONT_WARN_CK_CLICK       1120
#define ID_TRAYMENU_DOUBLECLICK         32771
#define ID_TRAYMENU_LEFTCLICK           32772
#define ID_TRAYMENU_RIGHTCLICK          32773
#define IDR_MOUSETOOLTRAY               32774
#define ID_TRAYMENU_RESTORE             32775
#define ID_TRAYMENU_STOPMOUSETOOL       32776
#define ID_TRAYMENU_NEXTONLY            32777
#define ID_TRAYMENU_OPENGENERAL         32778
#define ID_TRAYMENU_OPENKEYS            32779
#define ID_TRAYMENU_OPENCONTEXT         32780
#define ID_TRAYMENU_CLOSEMOUSETOOL      32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        215
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1121
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
