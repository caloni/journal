// Vcpp.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "Vcpp.h"

__declspec(dllexport) int soma(int x, int y)
{
	return x + y;
}

__declspec(dllexport) double soma(double x, double y)
{
	return x + y;
}
