#include <windows.h>
#include <tchar.h>
#include <wininet.h>
#include <shlwapi.h>
#include <assert.h>

#pragma comment(lib, "shlwapi.lib")

#define MSG_BANK_DETECT \
	_T("Foi detectado que esse banco tem sido visitado ultimamente")
#define MSG_BLOG_DETECT \
	_T("Foi detectado que voc� costuma visitar blogues de boa qualidade! =)")

#define SIZEOF_ARRAY(a) ( sizeof(a) / sizeof(a[0]) )


typedef HANDLE (__stdcall* FP_FindFirstUrlCacheEntry)(
	LPCSTR lpszUrlSearchPattern,
	LPINTERNET_CACHE_ENTRY_INFO lpFirstCacheEntryInfo,
	LPDWORD lpcbCacheEntryInfo
	);

typedef BOOL (__stdcall* FP_FindNextUrlCacheEntry)(
	HANDLE hEnumHandle,
	LPINTERNET_CACHE_ENTRY_INFO lpNextCacheEntryInfo,
	LPDWORD lpcbCacheEntryInfo
	);

typedef BOOL (__stdcall* FP_FindCloseUrlCache)(
	HANDLE hEnumHandle
	);


FP_FindFirstUrlCacheEntry fpFindFirstUrlCacheEntry;
FP_FindNextUrlCacheEntry fpFindNextUrlCacheEntry;
FP_FindCloseUrlCache fpFindCloseUrlCache;


#ifdef UNICODE
#define FINDFIRSTURLCACHEENTRY_NAME "FindFirstUrlCacheEntryW"
#define FINDNEXTURLCACHEENTRY_NAME "FindNextUrlCacheEntryW"
#else
#define FINDFIRSTURLCACHEENTRY_NAME "FindFirstUrlCacheEntryA"
#define FINDNEXTURLCACHEENTRY_NAME "FindNextUrlCacheEntryA"
#endif
#define FINDCLOSEURLCACHE_NAME "FindCloseUrlCache"


bool LoadFuncs()
{
	if( HMODULE dll = LoadLibrary(_T("wininet.dll")) )
	{
		fpFindFirstUrlCacheEntry = (FP_FindFirstUrlCacheEntry)
			GetProcAddress(dll, FINDFIRSTURLCACHEENTRY_NAME);

		fpFindNextUrlCacheEntry = (FP_FindNextUrlCacheEntry)
			GetProcAddress(dll, FINDNEXTURLCACHEENTRY_NAME);

		fpFindCloseUrlCache = (FP_FindCloseUrlCache)
			GetProcAddress(dll, FINDCLOSEURLCACHE_NAME);

		if( fpFindFirstUrlCacheEntry 
			&& fpFindNextUrlCacheEntry 
			&& fpFindCloseUrlCache )
		{
			return true;
		}
	}

	return false;
}


bool ScanSite(PTSTR url)
{
	static PTSTR banks[] = {
		_T("itau.com.br"),
		_T("bancoreal.com.br"),
		_T("banrisul.com.br"),
		_T("bradesco.com.br"),
		_T("bb.com.br"),
		_T("caixa.gov.br"),
	};

	for( size_t i = 0; i < SIZEOF_ARRAY(banks); ++i )
	{
		if( StrStrI(url, banks[i]) )
		{
			MessageBox(NULL, MSG_BANK_DETECT, banks[i], MB_OK);
			return true;
		}
	}

	if( StrStrI(url, _T("caloni.com.br")) )
	{
		MessageBox(NULL, MSG_BLOG_DETECT, _T("caloni.com.br"), MB_OK);
		return true;
	}

	return false;
}


int WINAPI _tWinMain(HINSTANCE, HINSTANCE, PTSTR, int)
{
	static PTSTR patterns[] = {
		_T("0"),
		NULL,
		_T("Cookie:")
	};

	DWORD ret = ERROR_SUCCESS;
	LPINTERNET_CACHE_ENTRY_INFO cacheEntry;
	DWORD cacheEntrySize = 0x190;

	MessageBox(NULL, _T("Trojan test\r\n")
		_T("Desenvolvido por Wanderley Caloni ")
		_T("(wanderley@caloni.com.br)"),
		_T("www.caloni.com.br/blog"), MB_OK | MB_ICONINFORMATION);

	if( ! LoadFuncs() )
		return -1;

	cacheEntry = (LPINTERNET_CACHE_ENTRY_INFO) VirtualAlloc(NULL, cacheEntrySize, 
		MEM_COMMIT, PAGE_READWRITE);
	assert(cacheEntry);

	while( ret == ERROR_SUCCESS || ret == ERROR_NO_MORE_ITEMS )
	{
		for( size_t i = 0; i < SIZEOF_ARRAY(patterns); ++i )
		{
			DWORD cacheEntrySize2 = cacheEntrySize;
			HANDLE cacheH = fpFindFirstUrlCacheEntry(patterns[i], 
				cacheEntry, &cacheEntrySize2);

			if( cacheH )
			{
				do
				{
					if( ScanSite(cacheEntry->lpszSourceUrlName) )
						return -1;

					cacheEntrySize2 = cacheEntrySize;
				}
				while( fpFindNextUrlCacheEntry(cacheH, 
					cacheEntry, &cacheEntrySize2) );

				ret = GetLastError();
				if( ret == ERROR_NO_MORE_ITEMS )
					ret = ERROR_SUCCESS;

				fpFindCloseUrlCache(cacheH);
			}
			else
				ret = GetLastError();

			if( ret == ERROR_INSUFFICIENT_BUFFER )
			{
				cacheEntrySize = cacheEntrySize2;
				VirtualFree(cacheEntry, 0, MEM_RELEASE);
				cacheEntry = (LPINTERNET_CACHE_ENTRY_INFO) VirtualAlloc(NULL, 
					cacheEntrySize, MEM_COMMIT, PAGE_READWRITE);
				assert(cacheEntry);
				ret = ERROR_SUCCESS;
			}
		}

		Sleep(1000);
	}

	return (int) ret;
}
