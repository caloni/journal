#include "MoveSemantics.h"

using namespace std;

int main()
{
    cout << "\n\n== MoveSemantics #1 ==\n";
    MoveSemantics1();

    cout << "\n\n== MoveSemantics #2 ==\n";
    MoveSemantics2();

    cout << "\n\n== MoveSemantics #3 ==\n";
    MoveSemantics3();

    cout << "\n\n== MoveSemantics #4 ==\n";
    MoveSemantics4();

    cout << "\n\n== MoveSemantics #5 ==\n";
    MoveSemantics5();

    cout << "\n\n== MoveSemantics #6 ==\n";
    MoveSemantics6();

    cout << "\n\n== MoveSemantics #7 ==\n";
    MoveSemantics7();
}
