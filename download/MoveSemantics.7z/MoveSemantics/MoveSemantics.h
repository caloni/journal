#define _CRT_SECURE_NO_WARNINGS // tranqueiras da microsoft
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <utility>
#include <cstdio>

void MoveSemantics1();
void MoveSemantics2();
void MoveSemantics3();
void MoveSemantics4();
void MoveSemantics5();
void MoveSemantics6();
void MoveSemantics7();
