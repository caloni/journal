/* This file is just here to make autoheader happy, so it will generate
   config.h for me. */

#define FIRST_PTY_LETTER 'p'

#define HAVE_FCNTL_H 0

#define HAVE_GETHOSTNAME 0

#define HAVE_GETTIMEOFDAY 0

#define HAVE_RANDOM 0

#define HAVE_SYS_SOCKET_H 0

#undef IBMRTAIX

#define LAST_PTY_LETTER 'q'

#define PATCHLEVEL "0"

#define PRODUCT "xboard"

#undef PTY_ITERATION

#undef PTY_NAME_SPRINTF

#undef PTY_OPEN

#undef PTY_TTY_NAME_SPRINTF

#define REMOTE_SHELL "rsh"

#undef RTU

#undef UNIPLUS

#define USE_PTYS 0

#define VERSION "x.y"

#undef X_WCHAR

#undef ZIPPY

#undef ATTENTION 

#undef DEFINED_SYS_ERRLIST

#undef HAVE_LIBXPM

#define HAVE_USLEEP 0

#undef USE_XAW3D
