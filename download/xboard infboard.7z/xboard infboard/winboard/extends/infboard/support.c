/**
 * @author Wanderley Caloni Jr (blakhalk@ig.com.br).
 * @date 02.2004
 * 
 * Support functions.
 */

#include <ctype.h>

int ToLower (int c) { return tolower(c); }
int ToUpper (int c) { return toupper(c); }
