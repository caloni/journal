#pragma once
#include <windows.h>

int GetHouaissPath(char houaissPath[MAX_PATH]);
int GetBabylonBuilderPath(char babBuildPath[MAX_PATH]);
