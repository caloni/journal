#pragma once

int Decryptor();
