#pragma once
#include "Common.h"

DWORD BuildDictionary(PCTSTR babylonBuilderPath, H2BFiles* files, H2BOperation& op);
DWORD InstallDictionary(H2BFiles* files);
