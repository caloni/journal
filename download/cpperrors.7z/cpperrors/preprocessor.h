#ifndef __PREPROCESSOR_H__
#define __PREPROCESSOR_H__

int functionNotDefined(int a, int b);

#endif // __PREPROCESSOR_H__
