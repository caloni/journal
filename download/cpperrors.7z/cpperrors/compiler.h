#ifndef __COMPILER_H__
#define __COMPILER_H__

int compilerFuncionDoesNotExists(int a);

#endif // __COMPILER_H__
