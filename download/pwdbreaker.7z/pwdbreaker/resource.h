#define IDD_DIALOG1        101
#define IDC_EDIT1         1001
#define IDC_EDIT2         1002
#define IDC_STATIC1       1003
#define IDC_STATIC2       1004
