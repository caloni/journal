#include "resource.h"
#include <windows.h>
#include <tchar.h>
#include <ctype.h>

#define SIZEOF_ARRAY(a) ( sizeof(a) / sizeof(a[0]) )



HWND g_singleDialogHandle;

TCHAR g_currentPassword[MAX_PATH];
DWORD g_currentPasswordSize;

HANDLE g_bruteForceThread;
DWORD g_bruteForceThreadId;
BOOL g_bruteForceContinue;


bool IsValidChar(TCHAR ch)
{
	if( ( ch >= 'a' && ch <= 'z' )
		|| ( ch >= 'A' && ch <= 'Z' )
		|| ( ch >= '0' && ch <= '9' )
		|| ( ch == ' ' ) )
	{
		return true;
	}

	return false;
}


void IncrementPassword(PTSTR password, DWORD len)
{
	TCHAR newChar = password[0] + 1;

	while( ! IsValidChar(newChar) )
	{
		++newChar;

		if( newChar >= UCHAR_MAX )
		{
			newChar = 0;
			break;
		}
	}

	if( newChar < password[0] )
		IncrementPassword(password + 1, len - 1);

	password[0] = newChar;
}


DWORD WINAPI BruteForceThread(PVOID)
{
	for( ; ; )
	{
		TCHAR breakPassword[MAX_PATH];
		SecureZeroMemory(breakPassword, sizeof(breakPassword));

		TCHAR currentPassword[MAX_PATH];
		lstrcpy(currentPassword, g_currentPassword);

		while( g_bruteForceContinue )
		{
			if( lstrcmp(currentPassword, breakPassword) != 0 )
			{
				IncrementPassword(breakPassword, 
					SIZEOF_ARRAY(breakPassword) - 1);
			}

			SetDlgItemText(g_singleDialogHandle, IDC_EDIT2, breakPassword);
		}

		g_bruteForceContinue = TRUE;
	}

	return ERROR_SUCCESS;
}


void RestartBruteForceThread()
{
	g_bruteForceContinue = FALSE;
}


void StartBruteForceThread()
{
	g_bruteForceContinue = TRUE;
	g_bruteForceThread = CreateThread(NULL, 0, BruteForceThread, NULL, 
		0, &g_bruteForceThreadId);
}


INT_PTR CALLBACK DialogProc(HWND hwndDlg, UINT uMsg, 
							WPARAM wParam, LPARAM lParam)
{
	INT_PTR ret = TRUE;

	switch( uMsg )
	{
	case WM_INITDIALOG:
		g_singleDialogHandle = hwndDlg;
		StartBruteForceThread();
		break;
	case WM_COMMAND:
		if( LOWORD(wParam) == IDC_EDIT1 && HIWORD(wParam) == EN_CHANGE )
		{
			TCHAR pwd[MAX_PATH];

			if( GetDlgItemText(hwndDlg, IDC_EDIT1, 
				pwd, SIZEOF_ARRAY(pwd)) )
			{
				lstrcpy(g_currentPassword, pwd);
				g_currentPasswordSize = lstrlen(pwd);

				RestartBruteForceThread();
			}
		}
		break;
	case WM_CLOSE:
		EndDialog(hwndDlg, TRUE);
		break;
	default:
		ret = FALSE;
	}

	return ret;
}


int WINAPI WinMain(HINSTANCE, HINSTANCE, PSTR, int)
{
	DialogBox(NULL, MAKEINTRESOURCE(IDD_DIALOG1), NULL, DialogProc);
	ExitProcess(ERROR_SUCCESS);
}
