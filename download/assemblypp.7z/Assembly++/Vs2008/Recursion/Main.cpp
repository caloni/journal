#include "..\..\Recursion.h"

int main()
{
	FactorialPrint(6);
}
