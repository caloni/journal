#include "..\..\Algorithm.h"


int SimpleFunc(int y)
{
	int x = 2 + y;
	return x;
}

int main()
{
	ForSum();
	ForEachSum();

	//For();
	//ForEach();

	//Sort();
}
