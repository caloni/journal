#include "..\..\Algorithm.h"


int SimpleFunc(int a, int b, 
	int c, int d, int e, int f)
{
	int z = a + b + c + d + e + f;
	return z;
}

int main()
{
	//SimpleFunc(2, 3, 4, 5, 6, 7);

	ForSum();
	ForEachSum();

	//For();
	//ForEach();

	//Sort();
}
