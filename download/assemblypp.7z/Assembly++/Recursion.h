
void FactorialPrint(int n);
int Factorial(int n);
int FactorialTail(int n, int a = 1);
