#include <stdio.h>

int main()
{
	printf("Hello, Make!!\n");
	return 0;
}
