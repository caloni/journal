
bool IsEven(int number);
