#include "EvenOdd.h"

bool IsEven(int number)
{
    bool even = (number % 2) != 0;
    return even;
}
