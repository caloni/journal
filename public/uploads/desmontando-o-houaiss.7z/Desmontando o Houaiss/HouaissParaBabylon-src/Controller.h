#pragma once
#include <windows.h>

struct H2BFiles;

DWORD StartConversion(HouaissParaBabylonDialog* dlg);
DWORD StartInstallation(HouaissParaBabylonDialog* dlg, H2BFiles* files);
